"use strict";

const fs = require("node:fs");
const http = require("node:http");
const os = require("node:os");
const path = require("node:path");

const ROOT = __dirname;
const HOST = "0.0.0.0";
const PORT = Number.parseInt(process.env.FE_LAN_PORT || "4173", 10);

const MIME_TYPES = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".jpeg": "image/jpeg",
  ".jpg": "image/jpeg",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".webp": "image/webp"
};
const PUBLIC_FILES = new Set(["/index.html", "/keywords.html"]);
const PUBLIC_DIRECTORIES = ["/css/", "/data/", "/js/"];

const normalizeAddress = (address = "") => address.replace(/^::ffff:/, "");

const isPrivateLanAddress = (address) => {
  const normalized = normalizeAddress(address);
  if (normalized === "::1" || normalized.startsWith("127.")) return true;
  if (normalized.startsWith("10.") || normalized.startsWith("192.168.")) return true;
  if (normalized.startsWith("169.254.")) return true;
  const match = normalized.match(/^172\.(\d{1,3})\./);
  return Boolean(match && Number(match[1]) >= 16 && Number(match[1]) <= 31);
};

const sendText = (response, statusCode, message) => {
  response.writeHead(statusCode, {
    "Cache-Control": "no-store",
    "Content-Type": "text/plain; charset=utf-8",
    "X-Content-Type-Options": "nosniff"
  });
  response.end(message);
};

const server = http.createServer((request, response) => {
  if (!isPrivateLanAddress(request.socket.remoteAddress)) {
    sendText(response, 403, "LAN内からのみアクセスできます。\n");
    return;
  }

  if (request.method !== "GET" && request.method !== "HEAD") {
    response.setHeader("Allow", "GET, HEAD");
    sendText(response, 405, "Method Not Allowed\n");
    return;
  }

  let pathname;
  try {
    pathname = decodeURIComponent(new URL(request.url, "http://localhost").pathname);
  } catch (_) {
    sendText(response, 400, "Bad Request\n");
    return;
  }

  const requestedPath = pathname === "/" ? "/index.html" : pathname;
  const isPublicAsset = PUBLIC_FILES.has(requestedPath)
    || PUBLIC_DIRECTORIES.some((directory) => requestedPath.startsWith(directory));
  if (!isPublicAsset) {
    sendText(response, 404, "Not Found\n");
    return;
  }

  const filePath = path.resolve(ROOT, `.${requestedPath}`);
  const relativePath = path.relative(ROOT, filePath);
  if (relativePath.startsWith("..") || path.isAbsolute(relativePath)) {
    sendText(response, 403, "Forbidden\n");
    return;
  }

  fs.stat(filePath, (statError, stats) => {
    if (statError || !stats.isFile()) {
      sendText(response, 404, "Not Found\n");
      return;
    }

    response.writeHead(200, {
      "Cache-Control": "no-store",
      "Content-Length": stats.size,
      "Content-Type": MIME_TYPES[path.extname(filePath).toLowerCase()] || "application/octet-stream",
      "X-Content-Type-Options": "nosniff"
    });
    if (request.method === "HEAD") {
      response.end();
      return;
    }
    fs.createReadStream(filePath).pipe(response);
  });
});

server.on("error", (error) => {
  console.error(`[FE LAN] 起動できませんでした: ${error.message}`);
  process.exitCode = 1;
});

server.listen(PORT, HOST, () => {
  console.log(`[FE LAN] 起動しました (port ${PORT})`);
  for (const interfaces of Object.values(os.networkInterfaces())) {
    for (const item of interfaces || []) {
      if (item.family === "IPv4" && !item.internal && isPrivateLanAddress(item.address)) {
        console.log(`http://${item.address}:${PORT}/`);
      }
    }
  }
});
